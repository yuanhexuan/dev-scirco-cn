@echo off
.\lib\JCC.exe -h
pause
cmd